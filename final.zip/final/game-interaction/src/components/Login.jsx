// src/components/Login.js

import React, { useState } from 'react';
import { useHistory } from 'react-router-dom'; // Import the useHistory hook from react-router-dom

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const { email, password } = formData;
  const history = useHistory(); // Initialize the useHistory hook

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Send a login request to the backend and handle the response
    // If login is successful, redirect to the user dashboard
    history.push('/dashboard'); // Redirect to the user dashboard route
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        {/* ... (login form fields) */}
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
