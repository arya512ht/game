// src/components/UserDashboard.js

import React, { useState, useEffect } from 'react';

const UserDashboard = () => {
  const [userInteractions, setUserInteractions] = useState([]);
  const [recommendations, setRecommendations] = useState([]);

  // Fetch user interactions and recommendations when the component loads
  useEffect(() => {
    // Fetch user interactions from the backend
    fetch('/api/user-interactions') // Replace with your actual backend route
      .then((response) => response.json())
      .then((data) => {
        setUserInteractions(data);
      })
      .catch((error) => console.error('Error fetching user interactions:', error));

    // Fetch recommendations from the backend
    fetch('/api/recommendations') // Replace with your actual backend route
      .then((response) => response.json())
      .then((data) => {
        setRecommendations(data);
      })
      .catch((error) => console.error('Error fetching recommendations:', error));
  }, []);

  return (
    <div>
      <h2>User Dashboard</h2>

      {/* Display user interactions */}
      <div>
        <h3>User Interactions</h3>
        <ul>
          {userInteractions.map((interaction, index) => (
            <li key={index}>{interaction}</li>
          ))}
        </ul>
      </div>

      {/* Display recommendations */}
      <div>
        <h3>Recommendations</h3>
        <ul>
          {recommendations.map((recommendation, index) => (
            <li key={index}>{recommendation}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default UserDashboard;
